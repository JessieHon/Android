package cn.hbu.cs.maingrid;

import android.app.Activity;
import android.os.Bundle;

public class Intent3 extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent3);

    }
}