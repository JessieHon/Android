package cn.hbu.cs.maingrid;

public class Student {
    public static final String TABLE = "Student";// 表名
    public static final String KEY_ID = "id";// 列名
    public static final String KEY_name = "name";// 列名
    public static final String KEY_age = "age";// 列名

    public int student_ID;// property help us to keep data
    public String name;
    public int age;
}
