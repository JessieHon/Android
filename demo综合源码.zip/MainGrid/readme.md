### IDE：Android Studio 3.5 ；update to 4.1 2020.10.21
### OS：Windows 10 / windows server 2016
### Language：Java



![综合实验截图](https://github.com/HBU/AndroidTest/blob/master/MainGrid/image.jpg)
